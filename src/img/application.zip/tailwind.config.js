module.exports = {
  mode: "jit",
  content: [
    "./src/**/**/*.{js,ts,jsx,tsx,html,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,html,mdx}",
  ],
  darkMode: "class",
  theme: {
    screens: { lg: "1120px", xl: "1281px", "2xl": "1441px", "3xl": "1729px" },
    extend: {
      colors: {
        gray_301: "#e1e1e1",
        gray_400: "#c4c4c4",
        gray_500: "#92929d",
        indigo_50: "#e1e1fb",
        gray_900: "#11142d",
        deep_purple_500: "#5441d6",
        red_400: "#f04361",
        gray_300: "#e2e2ea",
        gray_50: "#f6f6fb",
        teal_300: "#42bca1",
        bluegray_300: "#9a9ab0",
        gray_900_a2: "#11142da2",
        white_A700: "#ffffff",
      },
      borderRadius: { radius2: "2px", radius8: "8px", radius20: "20px" },
      fontFamily: { mulish: "Mulish" },
      letterSpacing: { ls1: "1px" },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
