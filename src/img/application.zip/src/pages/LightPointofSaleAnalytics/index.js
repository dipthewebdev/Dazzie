import React from "react";

import {
  Stack,
  Column,
  List,
  Row,
  Text,
  Img,
  Line,
  Button,
  Input,
  SelectBox,
} from "components";

const LightPointofSaleAnalyticsPage = () => {
  return (
    <>
      <Stack className="bg-gray_50 font-mulish lg:h-[1000px] xl:h-[1144px] 2xl:h-[1286px] 3xl:h-[1543px] mx-[auto] w-[100%]">
        <Column className="absolute items-center right-[2%] top-[9%] w-[88%]">
          <List
            className="lg:gap-[24px] xl:gap-[28px] 2xl:gap-[32px] 3xl:gap-[38px] grid grid-cols-4 min-h-[auto] w-[100%]"
            orientation="horizontal"
          >
            <Column className="bg-white_A700 items-center justify-center lg:p-[12px] xl:p-[14px] 2xl:p-[16px] 3xl:p-[19px] rounded-radius8 w-[100%]">
              <Row className="justify-between 2xl:mt-[10px] 3xl:mt-[12px] lg:mt-[7px] xl:mt-[8px] w-[99%]">
                <Text className="font-bold mt-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  Customer
                </Text>
                <Img
                  src="images/img_arrowdown.svg"
                  className="xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px] lg:h-[9px] 2xl:w-[11px] 3xl:w-[13px] lg:w-[8px] xl:w-[9px]"
                  alt="arrowdown"
                />
              </Row>
              <Row className="items-center justify-between lg:mb-[5px] xl:mb-[6px] 2xl:mb-[7px] 3xl:mb-[8px] lg:mt-[14px] xl:mt-[16px] 2xl:mt-[19px] 3xl:mt-[22px] w-[100%]">
                <Text className="font-bold mt-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  1000
                </Text>
                <Text className="font-bold mb-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-red_400 tracking-ls1 w-[auto]">
                  -15%
                </Text>
              </Row>
            </Column>
            <Column className="bg-white_A700 items-center justify-center lg:p-[12px] xl:p-[14px] 2xl:p-[16px] 3xl:p-[19px] rounded-radius8 w-[100%]">
              <Row className="justify-between 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] w-[99%]">
                <Text className="font-bold mt-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  Orders
                </Text>
                <Img
                  src="images/img_arrowdown_11X11.svg"
                  className="xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px] lg:h-[9px] 2xl:w-[11px] 3xl:w-[13px] lg:w-[8px] xl:w-[9px]"
                  alt="arrowdown One"
                />
              </Row>
              <Row className="items-center justify-between lg:mb-[5px] xl:mb-[6px] 2xl:mb-[7px] 3xl:mb-[8px] lg:mt-[14px] xl:mt-[16px] 2xl:mt-[19px] 3xl:mt-[22px] w-[100%]">
                <Text className="font-bold mt-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  1050
                </Text>
                <Text className="font-bold mb-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-teal_300 tracking-ls1 w-[auto]">
                  +20%
                </Text>
              </Row>
            </Column>
            <Column className="bg-white_A700 items-center justify-center lg:p-[12px] xl:p-[14px] 2xl:p-[16px] 3xl:p-[19px] rounded-radius8 w-[100%]">
              <Row className="justify-between 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] w-[99%]">
                <Text className="font-bold mt-[2px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  Revenue
                </Text>
                <Img
                  src="images/img_arrowdown_11X11.svg"
                  className="xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px] lg:h-[9px] 2xl:w-[11px] 3xl:w-[13px] lg:w-[8px] xl:w-[9px]"
                  alt="arrowdown Two"
                />
              </Row>
              <Row className="justify-between lg:mb-[5px] xl:mb-[6px] 2xl:mb-[7px] 3xl:mb-[8px] lg:mt-[11px] xl:mt-[13px] 2xl:mt-[15px] 3xl:mt-[18px] w-[100%]">
                <Text className="font-bold mb-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  $50.000
                </Text>
                <Text className="font-bold mt-[3px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-teal_300 tracking-ls1 w-[auto]">
                  +10%
                </Text>
              </Row>
            </Column>
            <Column className="bg-white_A700 items-center justify-center lg:p-[12px] xl:p-[14px] 2xl:p-[16px] 3xl:p-[19px] rounded-radius8 w-[100%]">
              <Row className="justify-between 2xl:mt-[10px] 3xl:mt-[12px] lg:mt-[7px] xl:mt-[8px] w-[99%]">
                <Text className="font-bold mt-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  Nett Profit
                </Text>
                <Img
                  src="images/img_arrowdown_11X11.svg"
                  className="xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px] lg:h-[9px] 2xl:w-[11px] 3xl:w-[13px] lg:w-[8px] xl:w-[9px]"
                  alt="arrowdown Three"
                />
              </Row>
              <Row className="justify-between lg:mb-[5px] xl:mb-[6px] 2xl:mb-[7px] 3xl:mb-[8px] lg:mt-[11px] xl:mt-[13px] 2xl:mt-[15px] 3xl:mt-[18px] w-[100%]">
                <Text className="font-bold mb-[1px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                  $12.000
                </Text>
                <Text className="font-bold mt-[3px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-teal_300 tracking-ls1 w-[auto]">
                  +12%
                </Text>
              </Row>
            </Column>
          </List>
          <Stack className="lg:h-[484px] xl:h-[554px] 2xl:h-[623px] 3xl:h-[747px] lg:mt-[22px] xl:mt-[25px] 2xl:mt-[29px] 3xl:mt-[34px] w-[100%]">
            <Row className="absolute justify-between left-[0] w-[93%]">
              <Column className="bg-white_A700 justify-end lg:p-[11px] xl:p-[13px] 2xl:p-[15px] 3xl:p-[18px] rounded-radius8 w-[71%]">
                <Text className="font-bold leading-[120.00%] lg:mt-[17px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[27px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[6%]">
                  Latest Order
                </Text>
                <Stack className="lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] w-[100%]">
                  <Row className="absolute items-center justify-evenly w-[100%]">
                    <Stack className="lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] w-[84%]">
                      <Stack className="absolute lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] left-[6%] w-[73%]">
                        <Column className="absolute bg-gray_50 justify-end left-[0] lg:p-[16px] xl:p-[18px] 2xl:p-[21px] 3xl:p-[25px] w-[68%]">
                          <Text className="font-bold ml-[1px] mt-[4px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900_a2 tracking-ls1 w-[auto]">
                            Item
                          </Text>
                        </Column>
                        <Column className="absolute bg-gray_50 justify-end lg:p-[16px] xl:p-[18px] 2xl:p-[21px] 3xl:p-[25px] right-[0] w-[32%]">
                          <Text className="font-bold ml-[1px] mt-[4px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900_a2 tracking-ls1 w-[auto]">
                            Quality
                          </Text>
                        </Column>
                      </Stack>
                      <Column className="absolute bg-gray_50 justify-end lg:p-[16px] xl:p-[18px] 2xl:p-[21px] 3xl:p-[25px] right-[0] w-[21%]">
                        <Text className="font-bold ml-[1px] mt-[4px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900_a2 tracking-ls1 w-[auto]">
                          Revenue
                        </Text>
                      </Column>
                      <Column className="absolute bg-gray_50 items-end left-[0] lg:p-[13px] xl:p-[15px] 2xl:p-[17px] 3xl:p-[20px] w-[10%]">
                        <Text className="font-bold mb-[4px] lg:mt-[6px] xl:mt-[7px] 2xl:mt-[8px] 3xl:mt-[9px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900_a2 tracking-ls1 w-[auto]">
                          No.
                        </Text>
                      </Column>
                    </Stack>
                    <Column className="bg-gray_50 lg:p-[16px] xl:p-[18px] 2xl:p-[21px] 3xl:p-[25px] w-[16%]">
                      <Text className="font-bold ml-[1px] mt-[4px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900_a2 tracking-ls1 w-[auto]">
                        Net Profit
                      </Text>
                    </Column>
                  </Row>
                  <Line className="absolute bg-indigo_50 h-[0.5px] top-[0] w-[100%]" />
                </Stack>
                <Row className="items-center w-[97%]">
                  <Column className="bg-white_A700 items-center xl:p-[10px] 2xl:p-[12px] 3xl:p-[14px] lg:p-[9px] w-[6%]">
                    <Text className="font-normal lg:mb-[4px] xl:mb-[5px] 2xl:mb-[6px] 3xl:mb-[7px] 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                      01
                    </Text>
                  </Column>
                  <Column className="bg-white_A700 lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[22%]">
                    <Text className="font-normal ml-[3px] mt-[3px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                      Sashimi
                    </Text>
                  </Column>
                  <Stack className="lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] lg:ml-[132px] xl:ml-[151px] 2xl:ml-[170px] 3xl:ml-[204px] w-[50%]">
                    <Stack className="absolute lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] right-[0] w-[60%]">
                      <Column className="absolute bg-white_A700 items-end p-[3px] right-[0] w-[37%]">
                        <Text className="font-normal lg:my-[10px] xl:my-[12px] 2xl:my-[14px] 3xl:my-[16px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                          $710.68
                        </Text>
                      </Column>
                      <Column className="absolute bg-white_A700 left-[0] lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[63%]">
                        <Text className="font-normal mb-[1px] ml-[4px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                          $293.01
                        </Text>
                      </Column>
                    </Stack>
                    <Column className="absolute bg-white_A700 justify-end left-[0] lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[41%]">
                      <Text className="font-normal ml-[3px] mt-[3px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                        30
                      </Text>
                    </Column>
                  </Stack>
                </Row>
                <Row className="items-center mt-[1px] w-[97%]">
                  <Button className="font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-center tracking-ls1 w-[6%]">
                    02
                  </Button>
                  <Button className="font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-center tracking-ls1 w-[22%]">
                    Unagi - Grilled Eel
                  </Button>
                  <Stack className="lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] lg:ml-[132px] xl:ml-[151px] 2xl:ml-[170px] 3xl:ml-[204px] w-[50%]">
                    <Stack className="absolute lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] right-[0] w-[60%]">
                      <Text className="absolute bg-white_A700 font-normal not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] right-[0] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[87px]">
                        $779.58
                      </Text>
                      <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[147px]">
                        $739.65
                      </Text>
                    </Stack>
                    <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pb-[14px] xl:pb-[16px] 2xl:pb-[18px] 3xl:pb-[21px] lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:pt-[16px] xl:pt-[18px] 2xl:pt-[21px] 3xl:pt-[25px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[161px]">
                      30
                    </Text>
                  </Stack>
                </Row>
                <Row className="items-center mt-[1px] w-[97%]">
                  <Button className="font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-center tracking-ls1 w-[6%]">
                    03
                  </Button>
                  <Stack className="bg-white_A700 lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px] lg:ml-[17px] xl:ml-[19px] 2xl:ml-[22px] 3xl:ml-[26px] w-[26%]">
                    <div className="absolute bg-white_A700 lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px] left-[0] w-[73%]"></div>
                    <Text className="absolute font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                      Soba - Buckwheat Noodles
                    </Text>
                  </Stack>
                  <Stack className="lg:h-[46px] xl:h-[52px] 2xl:h-[59px] 3xl:h-[70px] xl:ml-[103px] 2xl:ml-[116px] 3xl:ml-[139px] lg:ml-[90px] w-[32%]">
                    <Text className="absolute bg-white_A700 font-normal h-[max-content] inset-y-[0] my-[auto] not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] right-[0] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[91px]">
                      $779.58
                    </Text>
                    <Text className="absolute bg-white_A700 font-normal h-[max-content] inset-y-[0] left-[0] my-[auto] not-italic lg:pb-[14px] xl:pb-[16px] 2xl:pb-[18px] 3xl:pb-[21px] lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:pt-[16px] xl:pt-[18px] 2xl:pt-[21px] 3xl:pt-[25px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[161px]">
                      30
                    </Text>
                  </Stack>
                  <Text className="bg-white_A700 font-normal lg:ml-[44px] xl:ml-[50px] 2xl:ml-[57px] 3xl:ml-[68px] not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[87px]">
                    $105.55
                  </Text>
                </Row>
                <List
                  className="gap-[0] min-h-[auto] w-[97%]"
                  orientation="vertical"
                >
                  <Row className="items-center my-[0] w-[100%]">
                    <Column className="bg-white_A700 items-center xl:p-[10px] 2xl:p-[12px] 3xl:p-[14px] lg:p-[9px] w-[6%]">
                      <Text className="font-normal lg:mb-[4px] xl:mb-[5px] 2xl:mb-[6px] 3xl:mb-[7px] 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                        04
                      </Text>
                    </Column>
                    <Column className="bg-white_A700 items-end xl:p-[10px] 2xl:p-[12px] 3xl:p-[14px] lg:p-[9px] w-[22%]">
                      <Text className="font-normal lg:mb-[4px] xl:mb-[5px] 2xl:mb-[6px] 3xl:mb-[7px] 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                        Onigiri - Rice Balls
                      </Text>
                    </Column>
                    <Stack className="lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] lg:ml-[132px] xl:ml-[151px] 2xl:ml-[170px] 3xl:ml-[204px] w-[50%]">
                      <Stack className="absolute lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] right-[0] w-[60%]">
                        <Column className="absolute bg-white_A700 items-end p-[3px] right-[0] w-[37%]">
                          <Text className="font-normal lg:my-[10px] xl:my-[12px] 2xl:my-[14px] 3xl:my-[16px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                            $475.22
                          </Text>
                        </Column>
                        <Column className="absolute bg-white_A700 left-[0] lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[63%]">
                          <Text className="font-normal mb-[1px] ml-[4px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                            $589.99
                          </Text>
                        </Column>
                      </Stack>
                      <Column className="absolute bg-white_A700 justify-end left-[0] lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[41%]">
                        <Text className="font-normal ml-[3px] mt-[3px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                          30
                        </Text>
                      </Column>
                    </Stack>
                  </Row>
                  <Line className="self-center w-[100%] h-[0.5px] bg-indigo_50" />
                  <Row className="items-center my-[0] w-[100%]">
                    <Column className="bg-white_A700 items-center xl:p-[10px] 2xl:p-[12px] 3xl:p-[14px] lg:p-[9px] w-[6%]">
                      <Text className="font-normal lg:mb-[4px] xl:mb-[5px] 2xl:mb-[6px] 3xl:mb-[7px] 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] 2xl:mt-[9px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                        05
                      </Text>
                    </Column>
                    <Column className="bg-white_A700 lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[22%]">
                      <Text className="font-normal ml-[3px] mt-[3px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                        Sashimi
                      </Text>
                    </Column>
                    <Stack className="lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] lg:ml-[132px] xl:ml-[151px] 2xl:ml-[170px] 3xl:ml-[204px] w-[50%]">
                      <Stack className="absolute lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] right-[0] w-[60%]">
                        <Column className="absolute bg-white_A700 items-end p-[3px] right-[0] w-[37%]">
                          <Text className="font-normal lg:my-[10px] xl:my-[12px] 2xl:my-[14px] 3xl:my-[16px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                            $767.50
                          </Text>
                        </Column>
                        <Column className="absolute bg-white_A700 left-[0] lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[63%]">
                          <Text className="font-normal mb-[1px] ml-[4px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                            $406.27
                          </Text>
                        </Column>
                      </Stack>
                      <Column className="absolute bg-white_A700 justify-end left-[0] lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[41%]">
                        <Text className="font-normal ml-[3px] mt-[3px] not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                          30
                        </Text>
                      </Column>
                    </Stack>
                  </Row>
                </List>
                <List
                  className="gap-[0] min-h-[auto] mt-[1px] w-[97%]"
                  orientation="vertical"
                >
                  <Row className="lg:my-[22px] xl:my-[25px] 2xl:my-[29px] 3xl:my-[34px] w-[100%]">
                    <Button className="font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-center tracking-ls1 w-[6%]">
                      06
                    </Button>
                    <Stack className="bg-white_A700 lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px] lg:ml-[16px] xl:ml-[18px] 2xl:ml-[21px] 3xl:ml-[25px] lg:mt-[16px] xl:mt-[18px] 2xl:mt-[21px] 3xl:mt-[25px] w-[23%]">
                      <div className="absolute bg-white_A700 lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px] left-[0] w-[82%]"></div>
                      <Text className="absolute font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                        Yakitori - Grilled Chicken
                      </Text>
                    </Stack>
                    <Stack className="lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] lg:ml-[106px] xl:ml-[121px] 2xl:ml-[137px] 3xl:ml-[164px] w-[50%]">
                      <Stack className="absolute lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] right-[0] w-[60%]">
                        <Text className="absolute bg-white_A700 font-normal not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] right-[0] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[87px]">
                          $948.55
                        </Text>
                        <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[147px]">
                          $396.84
                        </Text>
                      </Stack>
                      <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pb-[14px] xl:pb-[16px] 2xl:pb-[18px] 3xl:pb-[21px] lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:pt-[16px] xl:pt-[18px] 2xl:pt-[21px] 3xl:pt-[25px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[161px]">
                        30
                      </Text>
                    </Stack>
                  </Row>
                  <Line className="self-center w-[100%] h-[0.5px] bg-indigo_50" />
                  <Row className="lg:my-[22px] xl:my-[25px] 2xl:my-[29px] 3xl:my-[34px] w-[100%]">
                    <Button className="font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-center tracking-ls1 w-[6%]">
                      08
                    </Button>
                    <Stack className="bg-white_A700 lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px] lg:ml-[17px] xl:ml-[19px] 2xl:ml-[22px] 3xl:ml-[26px] lg:mt-[16px] xl:mt-[18px] 2xl:mt-[21px] 3xl:mt-[25px] w-[23%]">
                      <div className="absolute bg-white_A700 lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px] left-[0] w-[83%]"></div>
                      <Text className="absolute font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                        Flavored Soymilk Drinks
                      </Text>
                    </Stack>
                    <Stack className="lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] lg:ml-[108px] xl:ml-[124px] 2xl:ml-[140px] 3xl:ml-[168px] w-[50%]">
                      <Stack className="absolute lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] right-[0] w-[60%]">
                        <Text className="absolute bg-white_A700 font-normal not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] right-[0] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[87px]">
                          $778.35
                        </Text>
                        <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[147px]">
                          $778.35
                        </Text>
                      </Stack>
                      <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pb-[14px] xl:pb-[16px] 2xl:pb-[18px] 3xl:pb-[21px] lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:pt-[16px] xl:pt-[18px] 2xl:pt-[21px] 3xl:pt-[25px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[161px]">
                        30
                      </Text>
                    </Stack>
                  </Row>
                </List>
                <Row className="items-center lg:mb-[50px] xl:mb-[57px] 2xl:mb-[65px] 3xl:mb-[78px] w-[97%]">
                  <Button className="font-normal not-italic lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-center tracking-ls1 w-[6%]">
                    07
                  </Button>
                  <Input
                    className="font-normal not-italic p-[0] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] placeholder:text-gray_900 text-gray_900 tracking-ls1 w-[100%]"
                    wrapClassName="w-[22%]"
                    name="TableRow Four"
                    placeholder="Royal Milk Tea"
                  ></Input>
                  <Stack className="lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] lg:ml-[132px] xl:ml-[151px] 2xl:ml-[170px] 3xl:ml-[204px] w-[50%]">
                    <Stack className="absolute lg:h-[44px] xl:h-[50px] 2xl:h-[57px] 3xl:h-[68px] right-[0] w-[60%]">
                      <Text className="absolute bg-white_A700 font-normal not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] right-[0] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[87px]">
                        $106.58
                      </Text>
                      <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:py-[14px] xl:py-[16px] 2xl:py-[18px] 3xl:py-[21px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[147px]">
                        $767.50
                      </Text>
                    </Stack>
                    <Text className="absolute bg-white_A700 font-normal left-[0] not-italic lg:pb-[14px] xl:pb-[16px] 2xl:pb-[18px] 3xl:pb-[21px] lg:pl-[17px] xl:pl-[19px] 2xl:pl-[22px] 3xl:pl-[26px] lg:pt-[16px] xl:pt-[18px] 2xl:pt-[21px] 3xl:pt-[25px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[161px]">
                      30
                    </Text>
                  </Stack>
                </Row>
              </Column>
              <Line className="bg-bluegray_300 lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px] lg:mt-[28px] xl:mt-[32px] 2xl:mt-[36px] 3xl:mt-[43px] w-[3px]" />
            </Row>
            <Row className="absolute bg-white_A700 h-[max-content] inset-y-[0] justify-end my-[auto] p-[4px] right-[0] rounded-radius8 w-[32%]">
              <Column className="items-center lg:mb-[30px] xl:mb-[34px] 2xl:mb-[39px] 3xl:mb-[46px] lg:mt-[15px] xl:mt-[17px] 2xl:mt-[20px] 3xl:mt-[24px] w-[94%]">
                <Row className="items-center justify-between w-[100%]">
                  <Text className="font-bold lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                    Item Sold
                  </Text>
                  <SelectBox
                    className="font-bold lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-deep_purple_500 tracking-ls1 w-[51%]"
                    placeholderClassName="text-deep_purple_500"
                    name="Button"
                    placeholder="Best Sellers"
                    isSearchable={false}
                    isMulti={false}
                    indicator={
                      <Img
                        src="images/img_arrowdown_deep_purple_500.svg"
                        className="lg:w-[15px] lg:h-[10px] lg:mr-[19px] xl:w-[17px] xl:h-[11px] xl:mr-[22px] 2xl:w-[20px] 2xl:h-[13px] 2xl:mr-[25px] 3xl:w-[24px] 3xl:h-[15px] 3xl:mr-[30px]"
                        alt="arrow_down"
                      />
                    }
                  ></SelectBox>
                </Row>
                <Line className="bg-indigo_50 h-[1px] lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[100%]" />
                <Row className="items-center lg:mt-[17px] xl:mt-[20px] 2xl:mt-[23px] 3xl:mt-[27px] w-[98%]">
                  <div className="bg-gray_300 lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] rounded-radius8 lg:w-[49px] xl:w-[56px] 2xl:w-[64px] 3xl:w-[76px]"></div>
                  <Text className="font-bold lg:ml-[18px] xl:ml-[21px] 2xl:ml-[24px] 3xl:ml-[28px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                    Sashimi
                  </Text>
                  <Text className="font-bold lg:ml-[105px] xl:ml-[120px] 2xl:ml-[135px] 3xl:ml-[162px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_500 tracking-ls1 w-[auto]">
                    430 Items
                  </Text>
                </Row>
                <Row className="items-center lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[98%]">
                  <div className="bg-gray_300 lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] rounded-radius8 lg:w-[49px] xl:w-[56px] 2xl:w-[64px] 3xl:w-[76px]"></div>
                  <Text className="font-bold lg:ml-[18px] xl:ml-[21px] 2xl:ml-[24px] 3xl:ml-[28px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                    Unagi - Grilled Eel
                  </Text>
                  <Text className="font-bold lg:ml-[45px] xl:ml-[51px] 2xl:ml-[58px] 3xl:ml-[69px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_500 tracking-ls1 w-[auto]">
                    200 Items
                  </Text>
                </Row>
                <Row className="items-center lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[98%]">
                  <div className="bg-gray_300 lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] rounded-radius8 lg:w-[49px] xl:w-[56px] 2xl:w-[64px] 3xl:w-[76px]"></div>
                  <Text className="font-bold leading-[120.00%] lg:ml-[18px] xl:ml-[21px] 2xl:ml-[24px] 3xl:ml-[28px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[39%]">
                    Soba - Buckwheat Noodles
                  </Text>
                  <Text className="font-bold lg:ml-[41px] xl:ml-[47px] 2xl:ml-[53px] 3xl:ml-[63px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_500 tracking-ls1 w-[auto]">
                    180 Items
                  </Text>
                </Row>
                <Row className="items-center lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[98%]">
                  <div className="bg-gray_300 lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] rounded-radius8 lg:w-[49px] xl:w-[56px] 2xl:w-[64px] 3xl:w-[76px]"></div>
                  <Text className="font-bold lg:ml-[18px] xl:ml-[21px] 2xl:ml-[24px] 3xl:ml-[28px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                    Onigiri - Rice Balls
                  </Text>
                  <Text className="font-bold lg:ml-[42px] xl:ml-[48px] 2xl:ml-[54px] 3xl:ml-[64px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_500 tracking-ls1 w-[auto]">
                    120 Items
                  </Text>
                </Row>
                <Row className="items-center lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[98%]">
                  <div className="bg-gray_300 lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] rounded-radius8 lg:w-[49px] xl:w-[56px] 2xl:w-[64px] 3xl:w-[76px]"></div>
                  <Text className="font-bold leading-[120.00%] lg:ml-[17px] xl:ml-[20px] 2xl:ml-[23px] 3xl:ml-[27px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[34%]">
                    Yakitori - Grilled Chicken
                  </Text>
                  <Text className="font-bold lg:ml-[63px] xl:ml-[72px] 2xl:ml-[82px] 3xl:ml-[98px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_500 tracking-ls1 w-[auto]">
                    80 Items
                  </Text>
                </Row>
                <Row className="items-center lg:mt-[12px] xl:mt-[14px] 2xl:mt-[16px] 3xl:mt-[19px] w-[98%]">
                  <div className="bg-gray_300 lg:h-[50px] xl:h-[57px] 2xl:h-[65px] 3xl:h-[77px] rounded-radius8 lg:w-[49px] xl:w-[56px] 2xl:w-[64px] 3xl:w-[76px]"></div>
                  <Text className="font-bold lg:ml-[18px] xl:ml-[21px] 2xl:ml-[24px] 3xl:ml-[28px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                    Royal Milk Tea
                  </Text>
                  <Text className="font-bold 3xl:ml-[115px] lg:ml-[74px] xl:ml-[85px] 2xl:ml-[96px] lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_500 tracking-ls1 w-[auto]">
                    70 Items
                  </Text>
                </Row>
              </Column>
              <Stack className="lg:h-[382px] xl:h-[437px] 2xl:h-[492px] 3xl:h-[590px] lg:ml-[6px] xl:ml-[7px] 2xl:ml-[8px] 3xl:ml-[9px] 2xl:mt-[100px] 3xl:mt-[120px] lg:mt-[77px] xl:mt-[88px] w-[1%]">
                <Line className="absolute bg-gray_300 lg:h-[382px] xl:h-[437px] 2xl:h-[492px] 3xl:h-[590px] w-[4px]" />
                <Line className="absolute bg-deep_purple_500 lg:h-[100px] xl:h-[114px] 2xl:h-[129px] 3xl:h-[154px] rounded-radius2 top-[0] w-[4px]" />
              </Stack>
            </Row>
          </Stack>
        </Column>
        <Stack className="absolute lg:h-[1000px] xl:h-[1144px] 2xl:h-[1286px] 3xl:h-[1543px] w-[100%]">
          <aside className="absolute items-center left-[0] w-[8%]">
            <Column className="">
              <Row className="justify-evenly w-[100%]">
                <Column className="bg-white_A700 items-center justify-end lg:p-[21px] xl:p-[24px] 2xl:p-[28px] 3xl:p-[33px] w-[99%]">
                  <Img
                    src="images/img_grid.svg"
                    className="lg:h-[14px] xl:h-[16px] 2xl:h-[18px] 3xl:h-[21px] 2xl:mt-[108px] 3xl:mt-[129px] lg:mt-[84px] xl:mt-[96px] w-[32%]"
                    alt="grid"
                  />
                  <Column className="bg-deep_purple_500 items-center lg:mt-[32px] xl:mt-[37px] 2xl:mt-[42px] 3xl:mt-[50px] lg:p-[13px] xl:p-[15px] 2xl:p-[17px] 3xl:p-[20px] rounded-radius8 w-[100%]">
                    <Stack
                      className="bg-cover bg-repeat lg:h-[14px] xl:h-[16px] 2xl:h-[18px] 3xl:h-[21px] my-[1px] w-[100%]"
                      style={{
                        backgroundImage: "url('images/img_group7.svg')",
                      }}
                    >
                      <Img
                        src="images/img_group7.svg"
                        className="absolute lg:h-[14px] xl:h-[16px] 2xl:h-[18px] 3xl:h-[21px] w-[100%]"
                        alt="Vector"
                      />
                    </Stack>
                  </Column>
                  <Column className="items-center lg:mt-[31px] xl:mt-[36px] 2xl:mt-[41px] 3xl:mt-[49px] w-[39%]">
                    <Img
                      src="images/img_twotoneacti.svg"
                      className="lg:h-[15px] xl:h-[17px] 2xl:h-[20px] 3xl:h-[23px] w-[91%]"
                      alt="TwoToneActi"
                    />
                    <Img
                      src="images/img_save.svg"
                      className="lg:h-[14px] xl:h-[16px] 2xl:h-[18px] 3xl:h-[21px] lg:mt-[45px] xl:mt-[52px] 2xl:mt-[59px] 3xl:mt-[70px] w-[82%]"
                      alt="save"
                    />
                    <Img
                      src="images/img_trash.svg"
                      className="lg:h-[11px] xl:h-[12px] 2xl:h-[14px] 3xl:h-[16px] lg:mt-[48px] xl:mt-[55px] 2xl:mt-[62px] 3xl:mt-[74px] w-[82%]"
                      alt="trash"
                    />
                    <Img
                      src="images/img_user.svg"
                      className="lg:h-[17px] xl:h-[19px] 2xl:h-[22px] 3xl:h-[26px] lg:mt-[46px] xl:mt-[53px] 2xl:mt-[60px] 3xl:mt-[72px] w-[100%]"
                      alt="user"
                    />
                  </Column>
                  <Img
                    src="images/img_settings.svg"
                    className="lg:h-[15px] xl:h-[17px] 2xl:h-[20px] 3xl:h-[23px] lg:mb-[53px] xl:mb-[61px] 2xl:mb-[69px] 3xl:mb-[82px] lg:mt-[480px] xl:mt-[549px] 2xl:mt-[618px] 3xl:mt-[742px] lg:w-[14px] xl:w-[16px] 2xl:w-[19px] 3xl:w-[22px]"
                    alt="settings"
                  />
                </Column>
                <Line className="bg-gray_301 xl:h-[1052px] 2xl:h-[1183px] 3xl:h-[1420px] lg:h-[920px] lg:mt-[60px] xl:mt-[69px] 2xl:mt-[78px] 3xl:mt-[93px] w-[1px]" />
              </Row>
            </Column>
          </aside>
          <Column className="absolute items-center top-[0] w-[100%]">
            <Row className="bg-white_A700 items-center lg:p-[14px] xl:p-[16px] 2xl:p-[18px] 3xl:p-[21px] w-[100%]">
              <div className="bg-gray_300 lg:h-[32px] xl:h-[36px] 2xl:h-[41px] 3xl:h-[49px] lg:ml-[10px] xl:ml-[11px] 2xl:ml-[13px] 3xl:ml-[15px] rounded-radius8 lg:w-[31px] xl:w-[35px] 2xl:w-[40px] 3xl:w-[48px]"></div>
              <Text className="font-bold lg:ml-[6px] xl:ml-[7px] 2xl:ml-[8px] 3xl:ml-[9px] lg:text-[18px] xl:text-[21px] 2xl:text-[24px] 3xl:text-[28px] text-gray_900 tracking-ls1 w-[auto]">
                Dazzie
              </Text>
              <Img
                src="images/img_notification.svg"
                className="lg:h-[16px] xl:h-[18px] 2xl:h-[21px] 3xl:h-[25px] 2xl:ml-[1019px] 3xl:ml-[1223px] lg:ml-[792px] xl:ml-[906px] w-[1%]"
                alt="notification"
              />
              <Row className="items-end justify-center mb-[1px] lg:ml-[24px] xl:ml-[27px] 2xl:ml-[31px] 3xl:ml-[37px] w-[9%]">
                <div className="bg-gray_400 lg:h-[32px] xl:h-[37px] 2xl:h-[42px] 3xl:h-[50px] rounded-radius20 w-[32%]"></div>
                <Column className="mb-[1px] lg:ml-[12px] xl:ml-[14px] 2xl:ml-[16px] 3xl:ml-[19px] lg:mt-[3px] xl:mt-[4px] 2xl:mt-[5px] 3xl:mt-[6px] w-[55%]">
                  <Text className="font-bold lg:text-[12px] xl:text-[14px] 2xl:text-[16px] 3xl:text-[19px] text-gray_900 tracking-ls1 w-[auto]">
                    Sumanto
                  </Text>
                  <Text className="font-normal lg:mt-[3px] xl:mt-[4px] 2xl:mt-[5px] 3xl:mt-[6px] not-italic xl:text-[10px] 2xl:text-[12px] 3xl:text-[14px] lg:text-[9px] text-bluegray_300 tracking-ls1 w-[auto]">
                    Cashier
                  </Text>
                </Column>
              </Row>
            </Row>
            <Line className="bg-gray_301 h-[1px] w-[100%]" />
          </Column>
        </Stack>
      </Stack>
    </>
  );
};

export default LightPointofSaleAnalyticsPage;
